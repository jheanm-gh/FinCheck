/**
 * SINGLE SOURCE OF TRUTH for adviser identity, contact and compliance wording.
 *
 * Every value is marked with its provenance:
 *   VERIFIED    - taken from Harika's official Sanlam adviser profile (see sourceUrl)
 *   PLACEHOLDER - MUST be supplied/approved by Concept Wealth or Sanlam compliance
 *                 before this site goes live. Nothing here is invented.
 *
 * Fabricating FSP numbers, licence wording, qualifications or approvals is not
 * acceptable. Placeholders render visibly in non-production builds so they cannot
 * be shipped by accident (see src/lib/compliance.ts).
 */

export const PLACEHOLDER = Symbol('needs-compliance-input');
export type Placeholder = typeof PLACEHOLDER;

export const adviser = {
  // ---- VERIFIED: identity -------------------------------------------------
  name: 'Harika van der Merwe',
  role: 'Sanlam Financial Adviser',
  practice: 'Concept Wealth Hennopspark',
  city: 'Pretoria',
  province: 'Gauteng',
  country: 'South Africa',

  /** VERIFIED: her own words from the official profile. Used once, on /about. */
  positioning:
    'I am dedicated to helping businesses and individuals build long term financial ' +
    'confidence through tailor made wealth planning, risk management and investment strategies.',

  // ---- VERIFIED: contact --------------------------------------------------
  phoneDisplay: '083 331 6235',
  phoneE164: '+27833316235',
  whatsapp: 'https://wa.me/27833316235',
  /** CONFIRMED by the practice: .co.za, not the .com shown on the Sanlam profile. */
  email: 'harika.vandermerwe@conceptwealth.co.za',
  practiceEmail: 'jdhenry@conceptwealth.co.za',
  practiceAddress:
    'Sanlynn Building, Cnr Sanlam & Alkantrand Road, Lynnwood Manor, Pretoria, 0081',

  // ---- VERIFIED: official links -------------------------------------------
  links: {
    sanlamProfile:
      'https://www.sanlamadvice.co.za/bluestar/conceptwealth-hennopspark/adviser/harika-van-der-merwe/88842552158368',
    conceptWealth: 'https://www.sanlamadvice.co.za/bluestar/conceptwealth-hennopspark',
    linkedin: 'https://www.linkedin.com/in/harika-van-der-merwe-a46690254',

    /**
     * A Facebook /share/ redirect, not her canonical page URL. It resolves today but
     * these are not guaranteed stable — replace with the real page URL when you have it.
     */
    facebook: 'https://www.facebook.com/share/1EZwKsmDHm/',

    /** Her podcast. Genuine owned content, not a third-party resource. */
    podcast: 'https://open.spotify.com/show/033OI8ClChie4avziJnMMY',
    sanlamPrivacy: 'https://www.sanlam.com/sanlams-privacy-policy.php',
    sanlamTerms: 'https://www.sanlam.com/terms-of-use.php',
  },

  /**
   * VERIFIED: hosted on Sanlam's CDN. Do NOT hotlink in production without
   * permission — download, get sign-off, and serve from /public instead.
   */
  photoUrl: 'https://www.sanlamadvice.co.za/intermediary-images/8693',
  photoApproved: false,

  sourceUrl:
    'https://www.sanlamadvice.co.za/bluestar/conceptwealth-hennopspark/adviser/harika-van-der-merwe/88842552158368',
} as const;

/**
 * COMPLIANCE BLOCK — every value here is a placeholder.
 *
 * Harika appears on a Sanlam BlueStar practice site, which normally means she acts
 * as a REPRESENTATIVE under Sanlam's FSP licence rather than as an FSP in her own
 * right. That distinction changes the required disclosure wording materially, so it
 * must be confirmed rather than guessed.
 */
export const compliance = {
  /**
   * CONFIRMED: she advises as a REPRESENTATIVE under Sanlam's FSP licence via
   * BlueStar, not as an FSP in her own right. Drives the disclosure wording below.
   */
  capacity: 'representative' as 'fsp' | 'representative',

  /**
   * FSP licence number. Known to be Sanlam's, but approval to display it on this
   * site is still outstanding. Stays a placeholder until that sign-off exists —
   * knowing a number is not permission to broadcast it.
   */
  fspNumber: PLACEHOLDER as Placeholder,

  /** Full legal name of the licensed entity she represents. */
  licensedEntity: PLACEHOLDER as Placeholder,

  /** POPIA responsible party — the legal entity accountable for data collected here. */
  responsibleParty: PLACEHOLDER as Placeholder,

  /** POPIA Information Officer name + contact, as registered with the Regulator. */
  informationOfficer: PLACEHOLDER as Placeholder,

  /**
   * Product-supplier disclosure required by the FAIS General Code.
   * Sanlam's own footer line, reproduced verbatim from the official profile, is the
   * closest verified wording available. It describes Sanlam Life, NOT this website,
   * so it cannot stand alone as this site's disclosure.
   */
  sanlamEntityLine:
    'Sanlam Life Insurance Limited is a licensed Life Insurer, authorised Financial ' +
    'Services Provider and registered Credit Provider (NCRCP43).',

  /**
   * Did a Sanlam/Concept Wealth key individual approve this site as advertising?
   * The FAIS General Code requires pre-publication approval and a retained record.
   * Ship-blocking: leave false until written approval exists.
   */
  advertisingApproved: false,
} as const;

/** Non-negotiable wording shown on every tool output. Safe to ship as-is. */
export const disclaimers = {
  tool:
    'This tool gives an indicative estimate based only on the figures and assumptions ' +
    'you entered. It is general information for educational purposes, not financial ' +
    'advice and not a recommendation to buy any financial product.',

  check:
    'This check is a general orientation, not a diagnosis. It does not consider your ' +
    'full circumstances and is not financial advice. A proper advice process looks at ' +
    'far more than a short questionnaire can.',

  noProduct:
    'No product is recommended or implied here. Whether anything is suitable for you ' +
    'depends on your circumstances and needs a full advice process.',
} as const;

export const site = {
  /**
   * Named after Harika's podcast, so the site, the show and her voice are one brand.
   *
   * The domain stays climeo.dev (§2). A brand name that does not match its domain is a
   * real cost: people cannot guess the URL from the name or the name from the URL.
   * Accepted deliberately rather than by oversight.
   */
  name: 'More Than Just Money',

  /** Wordmark set on two lines. "More Than Just Money" at logo size is too wide. */
  nameLines: ['More Than', 'Just Money'] as const,

  /**
   * The podcast's full bilingual title. Her audience is Pretoria and the show is half
   * Afrikaans, so this is the honest full name even though the site brands in English.
   */
  nameFull: 'Meer as net geld / More than just money.',

  domain: 'https://climeo.dev',
  tagline: 'Know where you stand.',
  description:
    'A short, plain-language check of where your finances stand, and a direct line to ' +
    `${adviser.name}, ${adviser.role} at ${adviser.practice} in ${adviser.city}.`,
} as const;
